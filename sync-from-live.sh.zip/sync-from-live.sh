#!/bin/bash

# =============================================================
# sync-from-live.sh
# Syncs live DreamHost → local DDEV environment
# Usage: cd /path/to/your-project && bash sync-from-live.sh
# =============================================================

# ── LIVE SERVER CONFIG ────────────────────────────────────────
SSH_USER="riazlighttn"
SSH_HOST="new.lighttn.com"
SSH_PORT="22"
SSH_PASS="cpl2026cpl2026"
LIVE_URL="http://new.lighttn.com/"

# ── LIVE DATABASE CONFIG ──────────────────────────────────────
DB_NAME="riazlighttn"
DB_USER="riazlighttn"
DB_PASS="cpl2026cpl2026"
DB_HOST="mysql.lighttn.com"

# ── LOCAL DDEV CONFIG ─────────────────────────────────────────
DDEV_PROJECT="cpl"
LOCAL_URL="https://cpl.ddev.site"
WP_PATH="/var/www/html/public"   # WordPress path inside DDEV container

# ── AUTO DETECT PROJECT ROOT ──────────────────────────────────
LOCAL_PATH="$(pwd)"

# =============================================================

# ── COLORS FOR OUTPUT ─────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}======================================${NC}"
echo -e "${BLUE}   CPL — Live → Local Sync Script     ${NC}"
echo -e "${BLUE}======================================${NC}"
echo ""
echo -e "${YELLOW}📁 Local project path: ${LOCAL_PATH}${NC}"
echo -e "${YELLOW}🌐 Live site:          ${LIVE_URL}${NC}"
echo -e "${YELLOW}💻 Local site:         ${LOCAL_URL}${NC}"
echo ""

# ── CHECK: Homebrew is installed ──────────────────────────────
if ! command -v brew &>/dev/null; then
    echo -e "${YELLOW}⚠️  Homebrew not found. Installing...${NC}"
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    if ! command -v brew &>/dev/null; then
        echo -e "${RED}❌ Homebrew install failed. Please install manually from https://brew.sh${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ Homebrew installed.${NC}"
    echo ""
fi

# ── CHECK: sshpass is installed ───────────────────────────────
if ! command -v sshpass &>/dev/null; then
    echo -e "${YELLOW}⚠️  sshpass not found. Installing...${NC}"
    brew install hudochenkov/sshpass/sshpass
    if ! command -v sshpass &>/dev/null; then
        echo -e "${RED}❌ sshpass install failed. Please run: brew install hudochenkov/sshpass/sshpass${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ sshpass installed.${NC}"
    echo ""
fi

# ── CHECK: DDEV is installed ──────────────────────────────────
if ! command -v ddev &>/dev/null; then
    echo -e "${YELLOW}⚠️  DDEV not found. Installing...${NC}"
    brew install ddev/ddev/ddev
    if ! command -v ddev &>/dev/null; then
        echo -e "${RED}❌ DDEV install failed. Please install manually from https://ddev.readthedocs.io${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ DDEV installed.${NC}"
    echo ""
fi

# ── SAFETY CHECK: make sure we're inside a DDEV project ───────
if [ ! -f "${LOCAL_PATH}/.ddev/config.yaml" ]; then
    echo -e "${RED}❌ Error: No .ddev/config.yaml found in current directory.${NC}"
    echo -e "${RED}   Please cd into your DDEV project root and try again.${NC}"
    echo ""
    exit 1
fi

# ── SAFETY CHECK: make sure DDEV is running ───────────────────
if ! ddev describe "$DDEV_PROJECT" &>/dev/null; then
    echo -e "${YELLOW}⚠️  DDEV project not running. Starting DDEV...${NC}"
    ddev start
    echo ""
fi

# ── CONFIRM BEFORE PROCEEDING ─────────────────────────────────
echo -e "${RED}⚠️  WARNING: This will overwrite your local database and uploads.${NC}"
echo -e "${RED}   Local changes will be lost.${NC}"
echo ""
read -p "Are you sure you want to continue? (yes/no): " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
    echo ""
    echo -e "${YELLOW}🚫 Sync cancelled.${NC}"
    echo ""
    exit 0
fi

echo ""

# ── FIND REMOTE WP ROOT AUTOMATICALLY ────────────────────────
echo -e "${BLUE}🔍 Detecting remote WordPress path...${NC}"

REMOTE_WP_ROOT=$(sshpass -p "${SSH_PASS}" ssh -p "${SSH_PORT}" \
    -o StrictHostKeyChecking=no \
    "${SSH_USER}@${SSH_HOST}" \
    "find /home/${SSH_USER} -name 'wp-config.php' 2>/dev/null | head -1 | xargs dirname")

if [ -z "$REMOTE_WP_ROOT" ]; then
    echo -e "${RED}❌ Could not detect WordPress root on live server.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Found WordPress at: ${REMOTE_WP_ROOT}${NC}"
echo ""

# =============================================================
# STEP 1 — Sync uploads folder
# =============================================================
echo -e "${BLUE}📂 Step 1/4: Syncing uploads from live server...${NC}"
echo ""

sshpass -p "${SSH_PASS}" rsync -avz --progress \
    -e "ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no" \
    "${SSH_USER}@${SSH_HOST}:${REMOTE_WP_ROOT}/wp-content/uploads/" \
    "${LOCAL_PATH}/public/wp-content/uploads/"

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ Uploads synced successfully.${NC}"
else
    echo ""
    echo -e "${RED}❌ Uploads sync failed.${NC}"
    exit 1
fi

echo ""

# =============================================================
# STEP 2 — Export live database
# =============================================================
echo -e "${BLUE}🗄️  Step 2/4: Exporting live database...${NC}"
echo ""

# --no-tablespaces fixes the PROCESS privilege warning on shared hosting
sshpass -p "${SSH_PASS}" ssh -p "${SSH_PORT}" \
    -o StrictHostKeyChecking=no \
    "${SSH_USER}@${SSH_HOST}" \
    "mysqldump --no-tablespaces -u ${DB_USER} -p'${DB_PASS}' -h ${DB_HOST} ${DB_NAME} > /home/${SSH_USER}/live-backup.sql"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Live database exported.${NC}"
else
    echo -e "${RED}❌ Database export failed. Check your DB credentials.${NC}"
    exit 1
fi

echo ""

# =============================================================
# STEP 3 — Download database to local
# =============================================================
echo -e "${BLUE}⬇️  Step 3/4: Downloading database...${NC}"
echo ""

sshpass -p "${SSH_PASS}" rsync -avz --progress \
    -e "ssh -p ${SSH_PORT} -o StrictHostKeyChecking=no" \
    "${SSH_USER}@${SSH_HOST}:/home/${SSH_USER}/live-backup.sql" \
    "${LOCAL_PATH}/live-backup.sql"

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ Database downloaded.${NC}"
else
    echo ""
    echo -e "${RED}❌ Database download failed.${NC}"
    exit 1
fi

echo ""

# =============================================================
# STEP 4 — Import database into DDEV + fix URLs
# =============================================================
echo -e "${BLUE}📥 Step 4/4: Importing database into DDEV...${NC}"
echo ""

ddev import-db --file="${LOCAL_PATH}/live-backup.sql"

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ Database imported.${NC}"
else
    echo ""
    echo -e "${RED}❌ Database import failed.${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}🔗 Replacing live URLs with local DDEV URLs...${NC}"
ddev wp --path="${WP_PATH}" search-replace "${LIVE_URL}" "${LOCAL_URL}" --all-tables

echo ""
echo -e "${BLUE}🧹 Flushing cache...${NC}"
ddev wp --path="${WP_PATH}" cache flush

echo ""
echo -e "${BLUE}🗑️  Cleaning up temp files...${NC}"

# Remove local backup file
rm -f "${LOCAL_PATH}/live-backup.sql"

# Remove remote backup file
sshpass -p "${SSH_PASS}" ssh -p "${SSH_PORT}" \
    -o StrictHostKeyChecking=no \
    "${SSH_USER}@${SSH_HOST}" \
    "rm -f /home/${SSH_USER}/live-backup.sql"

# =============================================================
echo ""
echo -e "${GREEN}======================================${NC}"
echo -e "${GREEN}   ✅ Sync Complete!                  ${NC}"
echo -e "${GREEN}======================================${NC}"
echo ""
echo -e "${GREEN}🌐 Open your local site: ${LOCAL_URL}${NC}"
echo ""